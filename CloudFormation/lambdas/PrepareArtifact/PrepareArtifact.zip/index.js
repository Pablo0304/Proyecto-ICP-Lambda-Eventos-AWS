const AWS = require('aws-sdk');

const s3 = new AWS.S3();

exports.handler = async (event) => {
  const { sourceBucket, sourceKey, artifactsBucket } = event;
  if (!sourceBucket || !sourceKey || !artifactsBucket) {
    throw new Error('Missing sourceBucket, sourceKey, or artifactsBucket');
  }

  const artifactKey = `artifacts/${Date.now()}-${sourceKey}`;

  await s3.copyObject({
    Bucket: artifactsBucket,
    CopySource: `${sourceBucket}/${encodeURIComponent(sourceKey)}`,
    Key: artifactKey
  }).promise();

  return {
    artifactsBucket,
    artifactKey
  };
};
