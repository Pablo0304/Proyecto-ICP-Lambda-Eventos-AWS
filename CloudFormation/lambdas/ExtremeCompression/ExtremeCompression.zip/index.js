const AWS = require('aws-sdk');
const zlib = require('zlib');

const s3 = new AWS.S3();

exports.handler = async (event) => {
  const { artifactsBucket, artifactKey, compression } = event;
  if (!artifactsBucket || !artifactKey) {
    throw new Error('Missing artifactsBucket or artifactKey');
  }

  const requestedLevel =
    compression && Number.isInteger(compression.level) ? compression.level : 9;
  const level = Math.max(-1, Math.min(9, requestedLevel));
  const compressedKey = `compressed/${Date.now()}-${artifactKey.split('/').pop()}.gz`;

  const obj = await s3
    .getObject({ Bucket: artifactsBucket, Key: artifactKey })
    .promise();

  const originalBody = Buffer.isBuffer(obj.Body)
    ? obj.Body
    : Buffer.from(obj.Body);

  const compressedBody = await new Promise((resolve, reject) => {
    zlib.gzip(
      originalBody,
      { level },
      (err, result) => (err ? reject(err) : resolve(result))
    );
  });

  await s3
    .putObject({
      Bucket: artifactsBucket,
      Key: compressedKey,
      Body: compressedBody,
      ContentType: obj.ContentType || 'application/octet-stream',
      ContentEncoding: 'gzip',
      Metadata: {
        compression: 'gzip',
        level: String(level)
      }
    })
    .promise();

  return {
    artifactsBucket,
    compressedKey,
    compression: {
      algorithm: 'gzip',
      level
    }
  };
};
