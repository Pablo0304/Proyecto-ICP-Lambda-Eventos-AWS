const AWS = require('aws-sdk');

const sfn = new AWS.StepFunctions();

exports.handler = async (event, context) => {
  const record = event.Records && event.Records[0];
  if (!record || !record.s3 || !record.s3.bucket || !record.s3.object) {
    throw new Error('Invalid S3 event');
  }

  const sourceBucket = record.s3.bucket.name;
  const sourceKey = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
  const stateMachineName = process.env.STATE_MACHINE_NAME;
  const stateMachineArn = `arn:aws:states:${process.env.AWS_REGION}:${context.invokedFunctionArn.split(':')[4]}:stateMachine:${stateMachineName}`;

  const input = {
    sourceBucket,
    sourceKey
  };

  const execName = `exec-${Date.now()}`;

  const result = await sfn.startExecution({
    stateMachineArn,
    name: execName,
    input: JSON.stringify(input)
  }).promise();

  return {
    executionArn: result.executionArn,
    startDate: result.startDate
  };
};
