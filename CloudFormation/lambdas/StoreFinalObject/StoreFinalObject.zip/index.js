const AWS = require('aws-sdk');

const s3 = new AWS.S3();

exports.handler = async (event) => {
  const { artifactsBucket, compressedKey, outputBucket } = event;
  if (!artifactsBucket || !compressedKey || !outputBucket) {
    throw new Error('Missing artifactsBucket, compressedKey, or outputBucket');
  }

  const outputKey = `final/${compressedKey.split('/').pop()}`;

  await s3.copyObject({
    Bucket: outputBucket,
    CopySource: `${artifactsBucket}/${encodeURIComponent(compressedKey)}`,
    Key: outputKey
  }).promise();

  return {
    outputBucket,
    outputKey
  };
};
