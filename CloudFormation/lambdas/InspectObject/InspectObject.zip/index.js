const AWS = require('aws-sdk');

const s3 = new AWS.S3();

exports.handler = async (event) => {
  const { sourceBucket, sourceKey } = event;
  if (!sourceBucket || !sourceKey) {
    throw new Error('Missing sourceBucket or sourceKey');
  }

  const head = await s3.headObject({
    Bucket: sourceBucket,
    Key: sourceKey
  }).promise();

  return {
    sourceBucket,
    sourceKey,
    size: head.ContentLength,
    contentType: head.ContentType || 'application/octet-stream'
  };
};
