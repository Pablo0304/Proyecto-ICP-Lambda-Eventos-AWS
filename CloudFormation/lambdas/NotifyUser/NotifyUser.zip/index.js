const AWS = require('aws-sdk');

const sns = new AWS.SNS();

exports.handler = async (event) => {
  const { topicArn, message, details } = event;
  if (!topicArn || !message) {
    throw new Error('Missing topicArn or message');
  }

  await sns.publish({
    TopicArn: topicArn,
    Message: JSON.stringify({ message, details })
  }).promise();

  return { status: 'notified' };
};
